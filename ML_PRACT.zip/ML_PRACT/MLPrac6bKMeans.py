#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans


# In[4]:


data=pd.read_csv("C:/Faiza/MSC IT/Sem 3/Machine Learning/ML/Datasets/segmented_customers.csv")
data


# In[5]:


data.head()


# In[6]:


data.tail()


# In[8]:


data.shape


# In[9]:


data.describe()


# In[10]:


data.info()


# In[11]:


data.isnull()


# In[12]:


data.isnull().sum()


# In[14]:


x=data['Age']
y=data['Spending Score (1-100)']
plt.scatter(x,y)
plt.title('Age vs Spending Score')
plt.xlabel('Age')
plt.ylabel('Spending Score')
plt.show()


# In[17]:


data=list(zip(x,y))
inertias=[]
for i in range(1,11):
    kmeans=KMeans(n_clusters=i)
    kmeans.fit(data)
    inertias.append(kmeans.inertia_)

plt.plot(range(1,11),inertias,marker='o')
plt.title('Elbow method')
plt.xlabel('No. of clusters')
plt.ylabel('Inertias')
plt.show()


# In[20]:


kmeansdata=list(zip(x,y))
kmeans=KMeans(n_clusters=5)
kmeans.fit(kmeansdata)
plt.scatter(x,y,c=kmeans.labels_)
plt.title('clusters')
plt.xlabel('Age')
plt.ylabel('Spending score')
plt.show()


# In[ ]:




